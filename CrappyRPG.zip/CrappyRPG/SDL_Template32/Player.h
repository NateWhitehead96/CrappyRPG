#pragma once
#include "GameObject.h"


class Player : public GameObject
{
private:
	int m_Health = 0;
	int m_Attack = 0;
	SDL_Rect m_Src = {0,0,32,32};
	SDL_Rect m_Dst = {0,0, 96,96};
	SDL_RendererFlip m_Flip = SDL_FLIP_NONE;
	// X Shit
	int m_dAccelX = 0;
	int m_dMaxAccelX = 0;
	int m_dVelocityX = 0;
	int m_dMaxVelX = 0;
	// Y shit
	int m_dAccelY = 0;
	int m_dMaxAccelY = 0;
	int m_dVelocityY = 0;
	int m_dMaxVelY = 0;

	int m_Direction = 0;
public:
	Player() {};
	Player(int h, int a, SDL_Rect playerselectSRC, SDL_Rect playerselectDST);
	~Player();

	void SetHealth(int h) { m_Health = h; }
	int GetHealth() { return m_Health; }
	void SetAttack(int a) { m_Attack = a; }
	int GetAttack() { return m_Attack; }
	SDL_Rect GetSrc() { return m_Src; }
	void SetSrc(int x, int y) { m_Src.x = x, m_Src.y = y; }
	SDL_Rect GetDst() { return m_Dst; }
	SDL_RendererFlip GetFlip() { return m_Flip; }
	void SetFlip(SDL_RendererFlip flipping) { m_Flip = flipping; }

	// Inherited via GameObject
	virtual void Update() override;
	virtual void Clean() override;
	virtual void Render() override;
	//Movement Stuff
	// X Stuff
	void SetX(int x) { m_Dst.x = x; }
	void SetAccelX(int x) { m_dAccelX = x; }
	//void SetVelX(double x) { m_dVelocityX = x; }
	int GetAccelX() { return m_dAccelX; }
	// Y Stuff
	void SetY(int y) { m_Dst.y = y; }
	void SetAccelY(int y) { m_dAccelY = y; }
	//void SetVelY(double y) { m_dVelocityY = y; }
	int GetAccelY() { return m_dAccelY; }

	void MoveX(int direction);
	void MoveY(int direction);
	void SetDir(int d) { m_Direction = d; }

	int m_iFrame = 0, // Frame counter.
		m_iFrameMax = 5, // Number of frames to display each sprite.
		m_iSprite = 0, // Sprite counter.
		m_iSpriteMax = 3; // Number of sprites in animation.
	void Animate();

	bool LeftCheck(SDL_Rect left);
	bool RightCheck(SDL_Rect right);
	bool TopCheck(SDL_Rect top);
	bool BotCheck(SDL_Rect bot);
	void EnemyCollision(SDL_Rect enemy);
};

