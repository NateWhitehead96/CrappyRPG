#pragma once
#include "SDL.h"

class Screen
{
public:
	Screen()
	{
		src.x = 0;
		src.y = 0;
	}
	SDL_Rect src = {0,0,1024, 768};
	SDL_Rect dst = { 0,0,1024, 768 };

	SDL_Rect topBound = {0, 0, 1024, 195};
	SDL_Rect bottomBound = {0, 650, 1024, 155};
	SDL_Rect leftBound = { 0,0,5,768 };
	SDL_Rect rightBound = { 1020, 0, 5, 768 };
};

class Button
{
public:
	Button(int x, int y)
	{
		src.x = x;
		src.y = y;
	}
	SDL_Rect src = {0,0,200,100};
	SDL_Rect dst = {0,0,200,100};

	bool MouseCheck(SDL_Point mouse, SDL_Rect button)
	{
		SDL_GetMouseState(&mouse.x, &mouse.y);
		if (SDL_PointInRect(&mouse, &button))
		{
			src.x = 200;
			return true;
		}
		else
		{
			src.x = 0;
			return false;
		}
	}
};