#pragma once
#include "SDL.h"

class Projectile
{
private:
	SDL_Rect m_Src = { 0,0,16,16 };
	SDL_Rect m_Dst = { 0, 0, 32,32 };
	SDL_RendererFlip m_Flip = SDL_FLIP_NONE;
	int m_MoveSpeed;
	int m_Direction;
	bool m_IsActive;

public:
	Projectile(int x, int y, bool active);
	~Projectile() {};
	SDL_RendererFlip SetFlip();
	SDL_RendererFlip GetFlip() { return m_Flip; }
	void SetSrc(int x, int y) { m_Src.x = x, m_Src.y = y; }
	SDL_Rect GetSrc() { return m_Src; }
	void SetDst(int x, int y) { m_Dst.x = x, m_Dst.y = y; }
	SDL_Rect GetDst() { return m_Dst; }
	void SetSpeed(int speed) { m_MoveSpeed = speed; }
	int GetSpeed() { return m_MoveSpeed; }
	bool GetActive() { return m_IsActive; }

	void Update();
	void NotActive();
	void Shoot(int x, int y, int d);
	bool CollisionCheck(SDL_Rect collision);
	void EnemyCollision(SDL_Rect enemy);

};