#pragma once
#include "SDL.h"

class PlayerSelect
{
public:
	SDL_Rect dst{0,0,96,96};
	SDL_Rect src{ 0,0,32,32 };
	PlayerSelect(int x, int y)
	{
		src.x = x;
		src.y = y;
	}
	int m_iFrame = 0, // Frame counter.
		m_iFrameMax = 10, // Number of frames to display each sprite.
		m_iSprite = 0, // Sprite counter.
		m_iSpriteMax = 3; // Number of sprites in animation.
	void Animate()
	{
		if (m_iFrame == m_iFrameMax)
		{
			m_iFrame = 0;
			m_iSprite++;
			if (m_iSprite == m_iSpriteMax)
			{
				m_iSprite = 0;
			}
			src.x = m_iSprite * src.w;
		}
		m_iFrame++;
	}
	bool MouseCheck(SDL_Point mouse, SDL_Rect hero)
	{
		SDL_GetMouseState(&mouse.x, &mouse.y);
		if (SDL_PointInRect(&mouse, &hero))
		{
			//Animate();
			return true;
		}
		else
		{
			return false;
		}
	}
};