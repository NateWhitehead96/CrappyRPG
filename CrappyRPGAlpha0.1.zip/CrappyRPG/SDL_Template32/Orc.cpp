#include "Orc.h"



Orc::Orc(int x, int y, int dx, int dy)
{
	m_Src.x = x;
	m_Src.y = y;
	m_Dst.x = dx;
	m_Dst.y = dy;
	m_XAccel = 0;
	m_YAccel = 0;
	m_MaxAccelX = 5;
	m_MaxAccelY = 5;
	m_Direction = 1;
	m_Flip = SDL_FLIP_NONE;
	m_Alive = false;
	m_Health = 3;
}

Orc::~Orc()
{
}

void Orc::Animate()
{
	if (m_iFrame == m_iFrameMax)
	{
		m_iFrame = 0;
		m_iSprite++;
		if (m_iSprite == m_iSpriteMax)
		{
			m_iSprite = 0;
		}
		m_Src.x = m_iSprite * m_Src.w;
	}
	m_iFrame++;
}

void Orc::Update()
{
	/*m_Death.Dst.x = m_Dst.x;
	m_Death.Dst.y = m_Dst.y;*/
	//m_Dst.x = m_X;
	// X Update
	if (m_XAccel < m_MaxAccelX)
	{
		m_XAccel++;
	}
	//m_Dst.y = m_Y;
	if (m_YAccel < m_MaxAccelY)
	{
		m_YAccel++;
	}

	/*if (m_Alive == false)
	{
		m_Death.Animate();
	}
	else
		Animate();*/
	//Death();

}

void Orc::Seek(SDL_Rect player, int speed)
{
	if (m_Alive == true)
	{
		Animate();

		if (player.x > m_Dst.x)
		{
			m_Dst.x += speed;
		}
		if (player.x < m_Dst.x)
		{

			m_Dst.x -= speed;
		}
		if (player.y > m_Dst.y)
		{

			m_Dst.y += speed;
		}
		if (player.y < m_Dst.y)
		{

			m_Dst.y -= speed;
		}
		if (SDL_HasIntersection(&player, &m_Dst))
		{
			m_Intersecting = true;
		}
		else
			m_Intersecting = false;
		if (m_Intersecting == true)
		{
			m_Health--;
		}
	}
}


void Orc::Spawn()
{
	int side;
	side = rand() % 2;
	if (side == 0)
	{
	m_Dst.x = -96;
	SetFlip(SDL_FLIP_NONE);
	}
	else if (side == 1)
	{
		m_Dst.x = 1000;
		SetFlip(SDL_FLIP_HORIZONTAL);
	}
	m_Dst.y = 100 + rand() % 400;
	m_Health = 3;
	m_Alive = true;
}

bool Orc::Death()
{
	if (m_Health == 0)
	{
		m_Dst.x = -100;
		m_Dst.y = -100;
		m_Alive = false;
		return true;
	}
	else
		return false;
	/*m_Alive = false;
	m_Health = 3;
	m_Defeated = false;*/
}

OrcDeath::OrcDeath(int x, int y)
{
	Dst.x = x;
	Dst.y = y;
	Src.w = 32;
	m_Animating = true;
}

void OrcDeath::Animate()
{
	if (m_Animating == true)
	{
		if (m_iFrame == m_iFrameMax)
		{
			m_iFrame = 0;
			m_iSprite++;
			if (m_iSprite == m_iSpriteMax)
			{
				m_iSprite = 0;
			}
			Src.x = m_iSprite * Src.w;
		}
		m_iFrame++;
	}
}
