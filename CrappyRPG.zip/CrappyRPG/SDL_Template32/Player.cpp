#include "Player.h"
#include <iostream>
#include <algorithm>
using namespace std;

Player::Player(int h, int a, SDL_Rect playerselectSRC, SDL_Rect playerselectDST)
{
	m_Health = h;
	m_Attack = a;
	m_Dst = playerselectDST;
	m_Src = playerselectSRC;
	m_dAccelX = m_dVelocityX = 0;
	m_dMaxAccelX = 5.0;
	//m_dMaxVelX = 5.0;
	m_Direction = 1;
	m_dAccelY = m_dVelocityY = 0;
	m_dMaxAccelY = 5.0;
	//m_dMaxVelY = 5.0;
}

Player::~Player()
{
}

void Player::Update()
{
	//m_dAccelX = min(max(m_dAccelX, -m_dMaxAccelX), m_dMaxAccelX); // The clamps
	//m_dVelocityX = m_dAccelX;
	//m_dVelocityX = min(max(m_dVelocityX, -m_dMaxVelX), m_dMaxVelX);
	//SetX((int)m_dVelocityX + m_Dst.x);

	// X Update
	if (m_dAccelX < m_dMaxAccelX)
	{
		m_dAccelX++;
	}

	//m_dAccelY = min(max(m_dAccelY, -m_dMaxAccelY), m_dMaxAccelY); // The clamps
	//m_dVelocityY = m_dAccelY;
	//m_dVelocityY = min(max(m_dVelocityY, -m_dMaxVelY), m_dMaxVelY);
	//SetY((int)m_dVelocityY + m_Dst.y);

	// Y Update
	if (m_dAccelY < m_dMaxAccelY)
	{
		m_dAccelY++;
	}

	if (m_dAccelX > 0 || m_dAccelY > 0)
	{
		Animate();
	}
	else
		SetSrc(0, GetSrc().y);
}

void Player::Clean()
{
}

void Player::Render()
{
}

void Player::MoveX(int direction)
{
	//m_dAccelX += m_Direction * 0.1;
	m_Dst.x += m_dAccelX * direction;
}

void Player::MoveY(int direction)
{
	//m_dAccelY += m_Direction * 0.1;
	m_Dst.y += m_dAccelY* direction;
}

void Player::Animate()
{

	if (m_iFrame == m_iFrameMax)
	{
		m_iFrame = 0;
		m_iSprite++;
		if (m_iSprite == m_iSpriteMax)
		{
			m_iSprite = 0;
		}
		m_Src.x = m_iSprite * m_Src.w;
	}
	m_iFrame++;
}

bool Player::LeftCheck(SDL_Rect left)
{
	if (SDL_HasIntersection(&m_Dst, &left))
	{
		m_dAccelX = m_dVelocityX = 0.0;
		return true;
	}
	else
		return false;
}

bool Player::RightCheck(SDL_Rect right)
{
	if (SDL_HasIntersection(&m_Dst, &right))
	{
		m_dAccelX = m_dVelocityX = 0.0;
		return true;
	}
	else
		return false;
}

bool Player::TopCheck(SDL_Rect top)
{
	if (SDL_HasIntersection(&m_Dst, &top))
	{
		m_dAccelY = m_dVelocityY = 0.0;
		return true;
	}
	else
		return false;
}

bool Player::BotCheck(SDL_Rect bot)
{
	if (SDL_HasIntersection(&m_Dst, &bot))
	{
		m_dAccelY = m_dVelocityY = 0.0;
		return true;
	}
	else
	{
	return false;
	}
}

void Player::EnemyCollision(SDL_Rect enemy)
{
	if (SDL_HasIntersection(&enemy, &m_Dst))
	{
		m_Health--;
		std::cout << m_Health << std::endl;
	}
}
