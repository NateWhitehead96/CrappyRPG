#include <chrono>
#include <iostream>
#include "Game.h"
#define FPS 60
using namespace std;
using namespace chrono;

void Game::m_CheckState()
{
	switch (GetState())
	{
	case States::TITLE_STATE:
		// title stuff
		Title();
		break;
	case States::PLAYER_PICK_STATE:
		// Player picking
		CharSelect();
		break;
	case States::LEVEL_ONE_STATE:
		// Level one shit
		LevelOne();
		break;
	case States::WIN_STATE:
		// Win screen
		break;
	case States::LOSE_STATE:
		// Lose Screen
		LoseScreen();
		break;
	}
}

Game::Game() :m_bStarted(false), m_bRunning(false)
{
	cout << "Constructing engine." << endl;
	m_fps = (Uint32)round((1 / (double)FPS) * 1000); // Sets FPS in milliseconds and rounds.
}

Game* Game::Instance()
{
	static Game* instance = new Game();
	return instance;
}

void Game::Run(const char * title, int xPos, int yPos, int width, int height, int flags)
{
	if (m_bStarted == true)
		return;
	cout << "Starting game." << endl;
	m_bStarted = true;
	if (Init(title, xPos, yPos, width, height, flags) == false)
	{
		cout << "Cannot initialize game." << endl;
		return;
	}
	// Main engine loop here.
	while (Running())
	{
		Wake();
		HandleEvents(); // Not restricted to framerate.
		Update();
		Render();
		if (Running())
			Sleep();
	}
	// End main engine loop.
	Clean();
}

bool Game::Init(const char* title, const int xpos, const int ypos, 
			    const int width, const int height, const int flags)
{
	SetState(TITLE_STATE);
	// Attempt to initialize SDL.
	if (SDL_Init(SDL_INIT_EVERYTHING) == 0) // 0 is error code meaning success.
	{
		cout << "SDL init success!" << endl;
		// Initialize the window
		m_pWindow = SDL_CreateWindow(title, xpos, ypos, width, height, flags);
		if (m_pWindow != nullptr) // Window init success. 
		{
			cout << "Window creation successful!" << endl;
			m_pRenderer = SDL_CreateRenderer(m_pWindow, -1, 0);
			if (m_pRenderer != nullptr) // Renderer init success. 
			{
				SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "best");
				cout << "Renderer creation success!" << endl;
				if (IMG_Init(IMG_INIT_PNG) != 0)
				{
					// Loading Textures
					pSurface = IMG_Load("RPGSprites.png");
					m_SpriteTexture = SDL_CreateTextureFromSurface(m_pRenderer, pSurface);
					SDL_FreeSurface(pSurface);
					pSurface = IMG_Load("CrappyRPGTitle.png");
					m_TitleTexture = SDL_CreateTextureFromSurface(m_pRenderer, pSurface);
					SDL_FreeSurface(pSurface);
					pSurface = IMG_Load("StartScreenButtons.png");
					m_ButtonTexture = SDL_CreateTextureFromSurface(m_pRenderer, pSurface);
					SDL_FreeSurface(pSurface);
					pSurface = IMG_Load("HeroSelect.png");
					m_HeroSelTexture = SDL_CreateTextureFromSurface(m_pRenderer, pSurface);
					SDL_FreeSurface(pSurface);
					pSurface = IMG_Load("LevelOne.png");
					m_LevelOneTexture = SDL_CreateTextureFromSurface(m_pRenderer, pSurface);
					SDL_FreeSurface(pSurface);
					pSurface = IMG_Load("LoseScreen.png");
					m_LoseScreenTexture = SDL_CreateTextureFromSurface(m_pRenderer, pSurface);
					SDL_FreeSurface(pSurface);
				}
				else
				{
					cout << "Image init fail!" << endl;
					return false;// Image init fail.
				}
			}
			else
			{
				cout << "Renderer init fail!" << endl;
				return false; // Renderer init fail. 
			}
		}
		else
		{
			cout << "Window init fail!" << endl;
			return false; // Window init fail. 
		}
	}
	else
	{
		cout << "SDL init fail!" << endl;
		return false; // SDL init fail. 
	}
	srand((unsigned)time(NULL));
	m_iKeystates = SDL_GetKeyboardState(nullptr);
	m_bRunning = true;

	// Initializing stuff
	m_PS[0] = new PlayerSelect(0, 0);
	m_PS[0]->dst.x = 225;
	m_PS[0]->dst.y = 300;
	m_PS[1] = new PlayerSelect(0, 32);
	m_PS[1]->dst.x = 425;
	m_PS[1]->dst.y = 300;
	m_PS[2] = new PlayerSelect(0, 64);
	m_PS[2]->dst.x = 625;
	m_PS[2]->dst.y = 300;

	m_Title = new Screen();
	m_StartButton = new Button(0, 0);
	m_StartButton->dst.x = 200;
	m_StartButton->dst.y = 650;
	m_ExitButton = new Button(0, 100);
	m_ExitButton->dst.x = 600;
	m_ExitButton->dst.y = 650;
	m_Lose = new Screen();

	m_HeroSelect = new Screen();
	m_LevelOne = new Screen();
	
	m_Orcs[0] = new Orc(0, 160, 0, -100);
	m_Orcs[1] = new Orc(0, 160, 0, -150);
	m_Orcs[2] = new Orc(0, 160, 0, -100);
	
	return true;
}

bool Game::Running()
{
	return m_bRunning;
}

bool Game::KeyDown(SDL_Scancode c)
{
	if (m_iKeystates != nullptr)
	{
		if (m_iKeystates[c] == 1)
			return true;
		else
			return false;
	}
	return false;
}
// TITLE SCREEN ################################################################################################
void Game::Title() // The title Screen || Where the title splash and buttons are displayed
{
	m_StartButton->MouseCheck(m_Mouse, m_StartButton->dst);
	m_ExitButton->MouseCheck(m_Mouse, m_ExitButton->dst);
	if (event.type == SDL_MOUSEBUTTONUP)
	{
		if (m_ExitButton->MouseCheck(m_Mouse, m_ExitButton->dst))
		{
			m_bRunning = false;
		}
		if (m_StartButton->MouseCheck(m_Mouse, m_StartButton->dst))
		{
			SetState(PLAYER_PICK_STATE);
		}
	}
}
// CHARACTER SELECT #############################################################################################
void Game::CharSelect() // Will be the character select || Player will be able to choose from 1 of 3 characters
{
	if (m_PS[0]->MouseCheck(m_Mouse, m_PS[0]->dst))
	{
		m_PS[0]->Animate();
	}
	if (m_PS[1]->MouseCheck(m_Mouse, m_PS[1]->dst))
	{
		m_PS[1]->Animate();
	}
	if (m_PS[2]->MouseCheck(m_Mouse, m_PS[2]->dst))
	{
		m_PS[2]->Animate();
	}
	if (event.type == SDL_MOUSEBUTTONUP)
	{
		if (m_PS[0]->MouseCheck(m_Mouse, m_PS[0]->dst))
		{
			m_Player = new Player(10, 1, m_PS[0]->src, m_PS[0]->dst);
			m_Weapon = new Projectile(96, m_PS[0]->src.y, false);
			SetState(LEVEL_ONE_STATE);
		}
		if (m_PS[1]->MouseCheck(m_Mouse, m_PS[1]->dst))
		{
			m_Player = new Player(10, 1, m_PS[1]->src, m_PS[1]->dst);
			m_Weapon = new Projectile(96, m_PS[1]->src.y, false);
			SetState(LEVEL_ONE_STATE);
		}
		if (m_PS[2]->MouseCheck(m_Mouse, m_PS[2]->dst))
		{
			m_Player = new Player(10, 1, m_PS[2]->src, m_PS[2]->dst);
			m_Weapon = new Projectile(96, m_PS[2]->src.y, false);
			SetState(LEVEL_ONE_STATE);
		}
	}
}
// LEVEL ONE ####################################################################################
void Game::LevelOne()
{
	m_FrameCount = 0;
	
	// Orc Update
	for (int i = 0; i < 3; i++) 
	{
		if (m_Orcs[i] != nullptr)
		{
			m_Orcs[i]->Seek(m_Player->GetDst(), 1); // Orc's movement
			if (m_Weapon->CollisionCheck(m_Orcs[i]->GetDst())) // Weapon to orc collision check
			{
				m_Weapon->NotActive();
				m_Orcs[i]->SetHealth(m_Orcs[i]->GetHealth() - 1);
			}
			m_Player->EnemyCollision(m_Orcs[i]->GetDst()); // player and enemy collide
			if (m_Player->GetDst().x < m_Orcs[i]->GetDst().x)
			{
				m_Orcs[i]->SetFlip(SDL_FLIP_HORIZONTAL);
			}
			if (m_Player->GetDst().x > m_Orcs[i]->GetDst().x)
			{
				m_Orcs[i]->SetFlip(SDL_FLIP_NONE);
			}
			//if (m_KillCount <= 10)
			
			m_OrcDeaths[i] = new OrcDeath(m_Orcs[i]->GetDst().x, m_Orcs[i]->GetDst().y);
			m_OrcDeaths[i]->Animate();
			
			if (m_Orcs[i]->Death()) // Kill counter
			{
				m_KillCount++;
				std::cout << "Kills: " << m_KillCount << std::endl;
			}
			if (SDL_GetTicks() - m_FrameCount >= 3000 && m_Orcs[i]->GetAlive() == false) // Orc Spawning
			{
				if (m_KillCount <= 7)
				{
				m_Orcs[i]->Spawn();
				}
				
				m_FrameCount = SDL_GetTicks();
			}
		}
	}
	
	

	if (KeyDown(SDL_SCANCODE_A) && m_Player->LeftCheck(m_LevelOne->leftBound) == false)
	{
		m_Player->SetDir(-1);
		m_Player->SetFlip(SDL_FLIP_HORIZONTAL);
		m_Player->MoveX(-1);
	}
	if (KeyDown(SDL_SCANCODE_D) && m_Player->RightCheck(m_LevelOne->rightBound) == false)
	{
		m_Player->SetDir(1);
		m_Player->SetFlip(SDL_FLIP_NONE);
		m_Player->MoveX(1);
	}
	if (KeyDown(SDL_SCANCODE_W) && m_Player->TopCheck(m_LevelOne->topBound) == false)
	{
		m_Player->SetDir(-1);
		m_Player->MoveY(-1);
	}
	if (KeyDown(SDL_SCANCODE_S) && m_Player->BotCheck(m_LevelOne->bottomBound) == false)
	{
		m_Player->SetDir(1);
		m_Player->MoveY(1);
	}
	if (KeyDown(SDL_SCANCODE_SPACE))
	{
		if (m_Weapon->GetActive() == false) // Weapon firing
		{
			if (m_Player->GetFlip() == SDL_FLIP_HORIZONTAL)
			{
				m_Weapon->Shoot(m_Player->GetDst().x + 5, m_Player->GetDst().y, -1);
			}
			if (m_Player->GetFlip() == SDL_FLIP_NONE)
			{
				m_Weapon->Shoot(m_Player->GetDst().x + 5, m_Player->GetDst().y, 1);
			}
		}
	}
	if (m_Weapon->CollisionCheck(m_LevelOne->leftBound))
	{
		m_Weapon->NotActive();
	}
	if (m_Weapon->CollisionCheck(m_LevelOne->rightBound))
	{
		m_Weapon->NotActive();
	}
	if (m_Player->GetHealth() == 0)
	{
		SetState(LOSE_STATE);
	}
	// The Scenes updates
	m_Player->Update();
	m_Weapon->Update();
	if (m_KillCount == 10)
	{
		std::cout << "U Winners!" << std::endl;
	}
}
// WHEN YOU LOSE THE GAME
void Game::LoseScreen()
{
	m_ExitButton = new Button(0, 100);
	m_ExitButton->dst.x = 375;
	m_ExitButton->dst.y = 400;
	m_ExitButton->MouseCheck(m_Mouse, m_ExitButton->dst);
	if (event.type == SDL_MOUSEBUTTONUP)
	{
		if (m_ExitButton->MouseCheck(m_Mouse, m_ExitButton->dst))
		{
			m_bRunning = false;
		}
	}
}

void Game::Update()
{
	m_CheckState();
}

void Game::HandleEvents()
{
	//SDL_Event event;
	if (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT:
			m_bRunning = false;
			break;
		case SDL_KEYUP:
			if (event.key.keysym.sym == SDLK_a || event.key.keysym.sym == SDLK_d )
			{
				m_Player->SetAccelX(0);
			}
			if (event.key.keysym.sym == SDLK_w || event.key.keysym.sym == SDLK_s)
			{
				m_Player->SetAccelY(0);
			}
			if (event.key.keysym.sym == SDLK_q)
			{
				m_bRunning = false;
			}
			break;
		}
	}
}

void Game::Wake()
{
	m_start = SDL_GetTicks();
}

void Game::Sleep()
{
	m_end = SDL_GetTicks();
	m_delta = m_end - m_start;
	if (m_delta < m_fps) // Engine has to sleep.
		SDL_Delay(m_fps - m_delta);
}

void Game::Render()
{
	SDL_SetRenderDrawColor(m_pRenderer, 0, 0, 125, 255);
	SDL_RenderClear(m_pRenderer); // Clear the screen to the draw color.
	if (GetState() == TITLE_STATE)
	{
		SDL_RenderCopy(m_pRenderer, m_TitleTexture, &m_Title->src, &m_Title->dst);
		SDL_RenderCopy(m_pRenderer, m_ButtonTexture, &m_StartButton->src, &m_StartButton->dst);
		SDL_RenderCopy(m_pRenderer, m_ButtonTexture, &m_ExitButton->src, &m_ExitButton->dst);
	}
	if (GetState() == PLAYER_PICK_STATE)
	{
		SDL_RenderCopy(m_pRenderer, m_HeroSelTexture, &m_HeroSelect->src, &m_HeroSelect->dst);
		SDL_RenderCopy(m_pRenderer, m_SpriteTexture, &m_PS[0]->src, &m_PS[0]->dst);
		SDL_RenderCopy(m_pRenderer, m_SpriteTexture, &m_PS[1]->src, &m_PS[1]->dst);
		SDL_RenderCopy(m_pRenderer, m_SpriteTexture, &m_PS[2]->src, &m_PS[2]->dst);
	}
	if (GetState() == LEVEL_ONE_STATE)
	{
		SDL_RenderCopy(m_pRenderer, m_LevelOneTexture, &m_LevelOne->src, &m_LevelOne->dst);
		for (int i = 0; i < 3; i++)
		{
		SDL_RenderCopyEx(m_pRenderer, m_SpriteTexture, &m_Orcs[i]->GetSrc(), &m_Orcs[i]->GetDst(), 0, NULL, m_Orcs[i]->GetFlip());
		if (m_OrcDeaths[i] != nullptr && m_Orcs[i]->GetHealth() == 0)
			{
				SDL_RenderCopy(m_pRenderer, m_SpriteTexture, &m_OrcDeaths[i]->Src, &m_OrcDeaths[i]->Dst);
			}
		}
		SDL_RenderCopyEx(m_pRenderer, m_SpriteTexture, &m_Player->GetSrc(), &m_Player->GetDst(), 0, NULL, m_Player->GetFlip());
		SDL_RenderCopyEx(m_pRenderer, m_SpriteTexture, &m_Weapon->GetSrc(), &m_Weapon->GetDst(), 0, NULL, m_Weapon->SetFlip());
	}
	if (GetState() == LOSE_STATE)
	{
		SDL_RenderCopy(m_pRenderer, m_LoseScreenTexture, &m_Lose->src, &m_Lose->dst);
		SDL_RenderCopy(m_pRenderer, m_ButtonTexture, &m_ExitButton->src, &m_ExitButton->dst);
	}
	
	SDL_RenderPresent(m_pRenderer); // Draw anew.
}

void Game::Clean()
{
	cout << "Cleaning game. Bye!" << endl;
	SDL_DestroyRenderer(m_pRenderer);
	SDL_DestroyWindow(m_pWindow);
	IMG_Quit();
	SDL_Quit();
}