#pragma once
#include "SDL.h"

enum States
{
	TITLE_STATE,
	PLAYER_PICK_STATE,
	LEVEL_ONE_STATE,
	WIN_STATE,
	LOSE_STATE,
	NUM_OF_STATES
};

class StateMachine
{
private:
	States m_CurrentState;
public:
	StateMachine() { m_CurrentState = TITLE_STATE; }

	void SetState(States state) { m_CurrentState = state; }
	States GetState() { return m_CurrentState; }

};