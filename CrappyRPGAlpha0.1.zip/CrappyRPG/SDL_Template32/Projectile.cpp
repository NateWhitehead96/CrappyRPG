#include "Projectile.h"

Projectile::Projectile(int x, int y, bool active)
{
	m_Src.x = x;
	m_Src.y = y;
	m_Dst.x = -100;
	m_Dst.y = -100;
	m_IsActive = active;
	m_MoveSpeed = 0;
	m_Direction = 1;
}

SDL_RendererFlip Projectile::SetFlip()
{
	if (m_Direction == 1)
	{
		m_Flip = SDL_FLIP_NONE;
		return m_Flip;
	}
	if (m_Direction == -1)
	{
		m_Flip = SDL_FLIP_HORIZONTAL;
		return m_Flip;
	}
}

void Projectile::Update()
{
	m_Dst.x += m_MoveSpeed * m_Direction;
}

void Projectile::NotActive()
{
	m_IsActive = false;
	m_Dst.x = -100;
	m_Dst.y = -100;
	m_MoveSpeed = 0;
}

void Projectile::Shoot(int x, int y, int d)
{
	m_IsActive = true;
	m_Dst.x = x;
	m_Dst.y = y;
	m_Direction = d;
	m_MoveSpeed = 3;
}

bool Projectile::CollisionCheck(SDL_Rect collision)
{
	if (SDL_HasIntersection(&m_Dst, &collision))
	{
		//NotActive();
		return true;
	}
	else
	{
		return false;
	}
	
}

void Projectile::EnemyCollision(SDL_Rect enemy)
{
	if (SDL_HasIntersection(&enemy, &m_Dst))
	{
		NotActive();
	}
}
