#pragma once
#include "SDL.h"
class GameObject
{
protected:
	SDL_Rect m_Src;
	SDL_Rect m_Dst;
public:
	GameObject();
	~GameObject();

	virtual void Render() = 0;
	virtual void Update() = 0;
	virtual void Clean() = 0;
};

