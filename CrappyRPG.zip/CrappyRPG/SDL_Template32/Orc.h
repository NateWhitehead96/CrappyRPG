#pragma once
#include "SDL.h"
#include <iostream>

class Orc
{
private:
	SDL_Rect m_Src = {0,0,32,32};
	SDL_Rect m_Dst = {0,0, 96, 96};

	SDL_RendererFlip m_Flip;

	int m_X = 0, m_Y = 0;

	int m_XAccel;
	int m_YAccel, m_MaxAccelX, m_MaxAccelY;

	int m_Direction;
	bool m_Alive;
	bool m_Intersecting = false;
	int m_Health;

	//OrcDeath m_Death;

public:
	Orc(int x, int y,int dx, int dy);
	~Orc();

	SDL_Rect GetSrc() { return m_Src; }
	void SetSrc(SDL_Rect rect) { m_Src = rect; }
	SDL_Rect GetDst() { return m_Dst; }
	void SetDst(SDL_Rect rect) { m_Dst = rect; }
	void SetHealth(int h) { m_Health = h; }
	int GetHealth() { return m_Health; }
	bool GetAlive() { return m_Alive; }
	void SetAlive(bool alive) { m_Alive = alive; }
	SDL_RendererFlip GetFlip() { return m_Flip; }
	void SetFlip(SDL_RendererFlip flip) { m_Flip = flip; }

	int m_iFrame = 0, m_iFrameMax = 5, m_iSprite = 0, m_iSpriteMax = 3;
	void Animate();
	

	void Update();
	void Seek(SDL_Rect player, int speed);
	bool Death();
	void Spawn();
};

class OrcDeath
{
public:
	OrcDeath() {};
	SDL_Rect Src = { 96, 160, 32, 32 };
	SDL_Rect Dst = { 0,0,96,96 };
	bool m_Animating = true;
	OrcDeath(int x, int y);

	int m_iFrame = 0, m_iFrameMax = 300000, m_iSprite = 0, m_iSpriteMax = 3; 
	void Animate();
};

