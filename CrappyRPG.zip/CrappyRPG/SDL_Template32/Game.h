#pragma once
#include <vector>
#include "SDL.h"
#include "SDL_image.h"

#include "Player.h"
#include "Projectile.h"
#include "Orc.h"
#include "TitleScreen.h"
#include "PlayerSelect.h"
#include "StateMachine.h"
using namespace std;

class Game : public StateMachine
{
private:
	bool m_bStarted, m_bRunning;
	bool m_bGotTick;
	SDL_Window* m_pWindow;
	SDL_Renderer* m_pRenderer;
	// Textures for game
	SDL_Texture* m_SpriteTexture;
	SDL_Texture* m_TitleTexture;
	SDL_Texture* m_ButtonTexture;
	SDL_Texture* m_HeroSelTexture;
	SDL_Texture* m_LevelOneTexture;
	SDL_Texture* m_LoseScreenTexture;
	SDL_Surface* pSurface;

	const Uint8* m_iKeystates;
	Uint32 m_start, m_end, m_delta, m_fps;
	// Game Needed variables
	SDL_Event event;
	SDL_Point m_Mouse;
	Projectile* m_Weapon;
	Player* m_Player;
	PlayerSelect* m_PS[3];
	Orc* m_Orcs[3] = { nullptr }; // The basic orc enemy
	OrcDeath* m_OrcDeaths[3] = {nullptr};
	int m_KillCount = 0;
	int m_FrameCount = 0;
	// All of the Screens in the game
	Screen* m_Title;
	Screen* m_HeroSelect;
	Screen* m_LevelOne;
	Screen* m_Lose;
	Button* m_StartButton;
	Button* m_ExitButton;
	void m_CheckState();

	Game();
	bool Init(const char* title, const int xpos, const int ypos,
		const int width, const int height, const int flags);
	bool Running();
	void Update();
	void HandleEvents();
	void Wake();
	void Sleep();
	void Render();
	void Clean();

public:
	static Game* Instance();
	void Run(const char*, int, int, int, int, int);
	SDL_Window* GetWindow() { return m_pWindow; }
	SDL_Renderer* GetRenderer() { return m_pRenderer; }
	bool KeyDown(SDL_Scancode c);

	// Game State functions
	void Title();
	void CharSelect();
	void LevelOne();
	void LoseScreen();

};